/*
 * osl forward declarations
 *
 * $Copyright Open Broadcom Corporation$
 *
 * $Id$
 */

#ifndef _osl_decl_h_
#define _osl_decl_h_

/* osl handle type forward declaration */
typedef struct osl_info osl_t;
typedef struct osl_dmainfo osldma_t;

#endif
