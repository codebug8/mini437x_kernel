/*
 * BCM common config options
 *
 * $Copyright Open Broadcom Corporation$
 *
 * $Id: bcm_cfg.h 351867 2012-08-21 18:46:16Z $
 */

#ifndef _bcm_cfg_h_
#define _bcm_cfg_h_
#endif /* _bcm_cfg_h_ */
